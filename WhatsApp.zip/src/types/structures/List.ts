import { Row } from "./Row"

export interface List {
  title: string
  rows: Row[]
  buttonText: string
}